# -*- coding: utf-8 -*-
"""
Created on Tue Jun 19 2018

@author: Vacian
"""
#p State Dos Plus

import numpy

x = numpy.loadtxt('1')
a = numpy.loadtxt('3')
b = numpy.loadtxt('4')
c = numpy.loadtxt('5')

y = a+b+c
print(y)