# -*- coding: utf-8 -*-
"""
Created on Tue Jun 19 2018

@author: Vacian
"""
#s State Dos Plus

import numpy

x = numpy.loadtxt('1')
a = numpy.loadtxt('2')

y =a

print(y)