#!/bin/bash

a=$1;
tar -czvf $a.tar.gz $a/